
 
         <link rel="stylesheet" href="css/Style9.css">
         <nav>
             <table >
             <tr>
             
             <td><a href="Bookings-details.php">Bookings</a></td>
             <td><a href="testimonials-page.php">Testimonials</a></td>
          
             <td><a href="users.php">Users</a></td>
             <td><div class="dropdown">
      <button class="dropbtn">Brands</button>
      <div class="dropdown-content">
        <a href="Manage-brand.php">Manage Brand</a>
        <a href="Add-brand.php">Add Brand</a>
      </div>
    </div></td>    <td><div class="dropdown">
      <button class="dropbtn">Vehicles</button>
      <div class="dropdown-content">
        <a href="Manage-vehicle.php">Manage Vehicles</a>
        <a href="add-vehicle.php">Add Vehicle</a>
      </div>
    </div></td>
    <td><a href="logout.php">Logout</a></td>
</tr>
</table>
         </nav>
         
    
    
     