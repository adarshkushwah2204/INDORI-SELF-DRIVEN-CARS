<?php 
session_start();
include('includes/config.php');
error_reporting(0);
?>

<html>
    <head>
<link rel="stylesheet" href="assets/CSSFILE/Style14.css">
<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
<style>
   
</style>
<?php include('navbar.php');?>
     </head>
     <body>
         <br><br><br><br>
     <section id="banner" class="banner-section-2">
  <div id="banner-text">
    
            <h1>About us</h1>
            <p>Know more about us and our business</p>
           
<a href="index.php" style="color:white;"> Home </a>>About
  </div>
</section>
<div id="quotes">

<p>
Indori self driven cars (website) is developed to provide people a web-application through which they can take and give cars on rent easily with the help of internet connectivity. Welcome to our car rental web application, where renting a car has never been easier. Whether you're planning a road trip, business trip, or just need a reliable vehicle for a few days, our platform has you covered.
With a user-friendly interface, you can easily search for available cars, compare prices, and make a reservation in just a few clicks. Our wide selection of vehicles caters to every need and budget, ranging from compact cars to luxury sedans and SUVs. Plus, with our transparent pricing, you can rest assured that you're getting the best deal possible.
But our service doesn't stop there. We're committed to providing excellent customer service and ensuring that your rental experience is as hassle-free as possible. Our team is always available to answer any questions you may have and help you with any issues that may arise during your rental period.
When you rent with us, you can enjoy the freedom and flexibility of having your own vehicle without the cost and commitment of owning one. You can explore new destinations, take spontaneous detours, and create memories that will last a lifetime.

</div>
<center>
    <br>
    <br>
<div id="content-table">
    <h2>Get Call :</h2><p>Give a missed call on 9522067784</p>
    <h2>E-mail:</h2><p> adarsh.kushwah22@gmail.com</p>

   <h2> Location <i class="fa fa-home" aria-hidden="true"></i><h2><p>Bhanwarkuwa,Indore </p>

</div>
<br><br>
</center>
<?php include('includes/footer.php');?>
</body>
</html>