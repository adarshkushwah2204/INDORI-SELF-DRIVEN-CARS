<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
<link rel="stylesheet" href="CarProject/assets/CSSFILE/Style.css">
<br><br><br><br><br><br><br><br><br><br><br><br><br><br>
 <div id="footer" style="text-align:left; color:white;">
   
     <a href="aboutus.php"><i class="material-icons">book</i> &nbsp;About us</a><br>
     <a href="admin/index.php"><i class="material-icons"></i> &nbsp;👨‍💻Admin Login</a><br>
     <h2>Call us on: 9522067784</h2>
     <h2>Developed by: Adarsh kushwah, Ashray patni , Aditya Dubey </h2>
     <h3>Copyright@2023</h3>
  
</div>
